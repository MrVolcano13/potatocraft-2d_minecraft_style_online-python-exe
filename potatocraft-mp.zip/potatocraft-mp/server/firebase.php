<?php
/* Minimal Firebase Realtime Database REST client (no Composer needed). */

class Firebase
{
    private string $url;
    private array $cfg;
    private ?string $token = null;

    public function __construct(array $cfg)
    {
        $this->cfg = $cfg;
        $this->url = rtrim($cfg['db_url'], '/');
        if ($this->url === '') {
            throw new RuntimeException('FIREBASE_DB_URL is not configured');
        }
    }

    // ---------------------------------------------------------------- auth
    private function b64u(string $s): string
    {
        return rtrim(strtr(base64_encode($s), '+/', '-_'), '=');
    }

    private function accessToken(): ?string
    {
        if ($this->cfg['db_secret'] !== '') {
            return null;                           // the secret is sent as ?auth=
        }
        if ($this->token !== null) {
            return $this->token;
        }
        $cache = sys_get_temp_dir() . '/potato_fb_token_' . md5($this->url) . '.json';
        if (is_file($cache)) {
            $c = json_decode((string)@file_get_contents($cache), true);
            if (is_array($c) && ($c['exp'] ?? 0) > time() + 60) {
                return $this->token = $c['token'];
            }
        }
        $sa = null;
        if ($this->cfg['sa_json'] !== '') {
            $sa = json_decode($this->cfg['sa_json'], true);
        } elseif ($this->cfg['sa_file'] !== '' && is_file($this->cfg['sa_file'])) {
            $sa = json_decode((string)file_get_contents($this->cfg['sa_file']), true);
        }
        if (is_array($sa) && isset($sa['private_key'], $sa['client_email'])) {
            $now = time();
            $head = $this->b64u(json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
            $claim = $this->b64u(json_encode([
                'iss' => $sa['client_email'],
                'scope' => 'https://www.googleapis.com/auth/firebase.database https://www.googleapis.com/auth/userinfo.email',
                'aud' => 'https://oauth2.googleapis.com/token',
                'iat' => $now, 'exp' => $now + 3600,
            ]));
            $sig = '';
            if (!openssl_sign("$head.$claim", $sig, $sa['private_key'], OPENSSL_ALGO_SHA256)) {
                throw new RuntimeException('Could not sign the service account JWT');
            }
            $res = $this->rawRequest('POST', 'https://oauth2.googleapis.com/token',
                http_build_query(['grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                                  'assertion' => "$head.$claim." . $this->b64u($sig)]),
                ['Content-Type: application/x-www-form-urlencoded']);
        } else {
            $res = $this->rawRequest('GET',
                'http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token',
                null, ['Metadata-Flavor: Google']);
        }
        $j = json_decode($res, true);
        if (!isset($j['access_token'])) {
            throw new RuntimeException('Could not get a Firebase access token');
        }
        $this->token = $j['access_token'];
        @file_put_contents($cache, json_encode(['token' => $this->token, 'exp' => time() + (int)($j['expires_in'] ?? 3000)]), LOCK_EX);
        return $this->token;
    }

    private function rawRequest(string $method, string $url, ?string $body, array $headers): string
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_HTTPHEADER => $headers,
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        $out = curl_exec($ch);
        curl_close($ch);
        return $out === false ? '' : (string)$out;
    }

    // ---------------------------------------------------------------- requests
    private function makeUrl(string $path, array $query = []): string
    {
        if ($this->cfg['db_secret'] !== '') {
            $query['auth'] = $this->cfg['db_secret'];
        } else {
            $query['access_token'] = $this->accessToken();
        }
        $qs = [];
        foreach ($query as $k => $v) {
            $qs[] = rawurlencode($k) . '=' . rawurlencode(is_string($v) ? $v : json_encode($v));
        }
        return $this->url . '/' . ltrim($path, '/') . '.json?' . implode('&', $qs);
    }

    /** Several GETs in parallel. $reqs = ['name' => [path, query], ...]; returns ['name' => decoded json]. */
    public function getMulti(array $reqs): array
    {
        $mh = curl_multi_init();
        $hs = [];
        foreach ($reqs as $name => [$path, $query]) {
            $ch = curl_init($this->makeUrl($path, $query));
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10, CURLOPT_CONNECTTIMEOUT => 5]);
            curl_multi_add_handle($mh, $ch);
            $hs[$name] = $ch;
        }
        do {
            $st = curl_multi_exec($mh, $running);
            if ($running) {
                curl_multi_select($mh, 1.0);
            }
        } while ($running && $st === CURLM_OK);
        $out = [];
        foreach ($hs as $name => $ch) {
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $body = curl_multi_getcontent($ch);
            curl_multi_remove_handle($mh, $ch);
            curl_close($ch);
            if ($code < 200 || $code >= 300) {
                throw new RuntimeException("Firebase GET $name failed ($code): " . substr((string)$body, 0, 200));
            }
            $out[$name] = json_decode((string)$body, true);
        }
        curl_multi_close($mh);
        return $out;
    }

    public function get(string $path, array $query = [])
    {
        return $this->getMulti(['x' => [$path, $query]])['x'];
    }

    private function write(string $method, string $path, $data): void
    {
        $ch = curl_init($this->makeUrl($path));
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10, CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_POSTFIELDS => json_encode($data, JSON_UNESCAPED_SLASHES),
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code < 200 || $code >= 300) {
            throw new RuntimeException("Firebase $method $path failed ($code): " . substr((string)$body, 0, 200));
        }
    }

    public function put(string $path, $data): void { $this->write('PUT', $path, $data); }

    /** Multi-path update: keys are paths relative to $path ("a/b/c" => value, null deletes). One round trip. */
    public function update(string $path, array $paths): void
    {
        if ($paths) {
            $this->write('PATCH', $path, $paths);
        }
    }
}
