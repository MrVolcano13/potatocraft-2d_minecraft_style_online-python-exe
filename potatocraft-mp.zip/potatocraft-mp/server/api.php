<?php
/*
 * PotatoCraft multiplayer API.  POST JSON to  api.php?action=join|sync|save|leave|ping
 * State lives in Firebase Realtime Database:
 *   rooms/{room}            seed, created, code_hash, pruned
 *   accounts/{room}/{name}  pw_hash
 *   pdata/{room}/{name}     blob (the player's saved inventory etc., opaque JSON string)
 *   players/{room}/{name}   live position + session token hash
 *   blocks/{room}/{dim}/{x}_{y} = block id     (every block that differs from the generated world)
 *   chests/{room}/{d}_{x}_{y}  {c: JSON string with the 27 slots}   (placed chests and shulker boxes)
 *   locks/{room}/{d}_{x}_{y}   {n: player, t: ms}   only the player who has a chest open may save it
 *   events/{room}/{key}     chronological log of block changes and chat (pruned after a few minutes)
 */
declare(strict_types=1);
require __DIR__ . '/firebase.php';

const WW = 360, WH = 120;          // must match potatocraft.py
const ONLINE_SECS = 12;            // a player not heard from for this long is considered gone
const MAX_EVENTS_PER_SYNC = 600;
const MAX_BLOB = 400000;
const LOCK_SECS = 15;              // an open chest is locked to one player; refreshed by every sync
const KICK_SECS = 120;             // /kick still finds players whose connection is slow or flaky

header('Content-Type: application/json');
header('Cache-Control: no-store');

function fail(string $msg, int $code = 400): never
{
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}

function now_ms(): int { return (int)floor(microtime(true) * 1000); }

$cfg = require __DIR__ . '/config.php';
$action = $_GET['action'] ?? '';
if ($action === 'ping') {
    echo json_encode(['ok' => true, 'game' => 'potatocraft', 'cheats' => $cfg['allow_cheats']]);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fail('POST only', 405);
}
$raw = file_get_contents('php://input');
if (strlen($raw) > 1500000) {
    fail('Request too large', 413);
}
$in = json_decode($raw, true);
if (!is_array($in)) {
    fail('Bad JSON');
}

$room = (string)($in['room'] ?? '');
$name = (string)($in['name'] ?? '');
if (!preg_match('/^[A-Za-z0-9_-]{1,24}$/', $room)) fail('Room name: 1-24 letters, digits, _ or -');
if (!preg_match('/^[A-Za-z0-9_]{2,16}$/', $name)) fail('Player name: 2-16 letters, digits or _');
$room = strtolower($room);

try {
    $fb = new Firebase($cfg);
    switch ($action) {
        case 'join':  do_join($fb, $cfg, $room, $name, $in); break;
        case 'sync':  do_sync($fb, $cfg, $room, $name, $in); break;
        case 'chest_open':  do_chest_open($fb, $room, $name, $in); break;
        case 'chest_close': do_chest_close($fb, $room, $name, $in); break;
        case 'chest_take':  do_chest_take($fb, $room, $name, $in); break;
        case 'kick':  do_kick($fb, $cfg, $room, $name, $in); break;
        case 'snapshot': do_snapshot($fb, $room, $name, $in); break;
        case 'save':  do_save($fb, $room, $name, $in); break;
        case 'leave': do_leave($fb, $room, $name, $in); break;
        default: fail('Unknown action');
    }
} catch (Throwable $e) {
    error_log('potatocraft: ' . $e->getMessage());
    fail('Server error', 500);
}

// ------------------------------------------------------------------ helpers
function new_event_key(int $ms, int $i): string
{
    return sprintf('%013d-%03d-%s', $ms, $i, bin2hex(random_bytes(2)));
}

function check_token(?array $player, string $token): void
{
    if (!$player || !isset($player['th']) || $token === '' || !hash_equals($player['th'], hash('sha256', $token))) {
        fail('Not logged in (session expired). Rejoin the server.', 401);
    }
}

function public_player(array $p): array
{
    return [
        'x' => (float)($p['x'] ?? 0), 'y' => (float)($p['y'] ?? 0), 'vx' => (float)($p['vx'] ?? 0),
        'f' => (int)($p['f'] ?? 1), 'd' => (int)($p['d'] ?? 0), 'hp' => (float)($p['hp'] ?? 20),
        'sw' => (float)($p['sw'] ?? 0), 'h' => (int)($p['h'] ?? 0),
    ];
}

// ------------------------------------------------------------------ join
function do_join(Firebase $fb, array $cfg, string $room, string $name, array $in): void
{
    $pw = (string)($in['pw'] ?? '');
    if (strlen($pw) < 4 || strlen($pw) > 64) fail('Password: 4-64 characters');

    $r = $fb->getMulti([
        'meta'    => ["rooms/$room", []],
        'account' => ["accounts/$room/$name", []],
        'players' => ["players/$room", []],
    ]);
    $meta = $r['meta'];
    $now = now_ms();
    if (!is_array($meta)) {                                   // first player creates the room
        if ($cfg['create_code'] !== '' && !hash_equals($cfg['create_code'], (string)($in['create_code'] ?? ''))) {
            fail('This server needs a create code to open a new room.', 403);
        }
        $meta = ['seed' => random_int(1, (1 << 30) - 1), 'created' => $now, 'pruned' => ''];
        $fb->put("rooms/$room", $meta);
    }

    $acct = $r['account'];
    if (is_array($acct) && isset($acct['pw_hash'])) {
        if (!password_verify($pw, $acct['pw_hash'])) fail('Wrong password for this player name.', 403);
    } else {
        $fb->put("accounts/$room/$name", ['pw_hash' => password_hash($pw, PASSWORD_DEFAULT), 'created' => $now]);
    }

    $online = 0;
    foreach ((array)$r['players'] as $pn => $p) {
        if (is_array($p) && ($p['seen'] ?? 0) > $now - ONLINE_SECS * 1000) {
            if ($pn === $name) fail('That player is already online.', 409);
            $online++;
        }
    }
    if ($online >= $cfg['max_players']) fail('Room is full.', 409);

    // cursor FIRST, snapshot second: replaying an event twice is harmless, missing one is not
    $last = $fb->get("events/$room", ['orderBy' => '"$key"', 'limitToLast' => 1]);
    $cursor = is_array($last) && $last ? (string)array_key_last($last) : '';
    $res = $fb->getMulti([
        'blocks' => ["blocks/$room", []],
        'pdata'  => ["pdata/$room/$name/blob", []],
    ]);

    $blocks = [];                                  // Firebase turns keys 0,1,2 into a JSON list: normalise
    foreach ((array)($res['blocks'] ?? []) as $d => $cells) {
        if (is_array($cells)) $blocks[(string)$d] = (object)$cells;
    }

    $token = bin2hex(random_bytes(16));
    $fb->update('', ["players/$room/$name" => [
        'th' => hash('sha256', $token), 'seen' => $now, 'x' => 0, 'y' => 0, 'd' => 0, 'f' => 1, 'hp' => 20,
    ], "events/$room/" . new_event_key($now, 0) => ['t' => 'j', 'n' => $name]]);

    echo json_encode([
        'ok' => true, 'token' => $token, 'seed' => (int)$meta['seed'],
        'time' => $now - (int)$meta['created'], 'cursor' => $cursor,
        'cheats' => $cfg['allow_cheats'], 'blocks' => (object)$blocks,
        'data' => is_string($res['pdata']) ? $res['pdata'] : null,
        'online' => $online + 1, 'admin' => in_array($name, $cfg['admins'], true),
    ]);
}

// ------------------------------------------------------------------ sync
function do_sync(Firebase $fb, array $cfg, string $room, string $name, array $in): void
{
    $token = (string)($in['token'] ?? '');
    $cursor = (string)($in['cursor'] ?? '');
    if (!preg_match('/^[0-9]{13}-[0-9]{3}-[0-9a-f]{4}$|^$/', $cursor)) fail('Bad cursor');
    $now = now_ms();

    $q = ['orderBy' => '"$key"', 'limitToFirst' => MAX_EVENTS_PER_SYNC];
    if ($cursor !== '') $q['startAt'] = json_encode($cursor);
    $r = $fb->getMulti([
        'players' => ["players/$room", []],
        'events'  => ["events/$room", $q],
        'meta'    => ["rooms/$room", []],
        'locks'   => ["locks/$room", []],
    ]);
    $players = is_array($r['players']) ? $r['players'] : [];
    check_token($players[$name] ?? null, $token);
    if (isset($players[$name]['kick'])) {
        fail('You were kicked: ' . $players[$name]['kick'], 401);
    }
    $meta = $r['meta'];
    if (!is_array($meta)) fail('Room no longer exists', 404);

    // ---- what the client sent
    $me = is_array($in['me'] ?? null) ? $in['me'] : [];
    $writes = [];
    $num = fn($v, $lo, $hi) => max($lo, min($hi, is_numeric($v) ? (float)$v : 0.0));
    $writes["players/$room/$name"] = [
        'th' => $players[$name]['th'], 'seen' => $now,
        'x' => round($num($me['x'] ?? 0, -10, WW + 10), 3), 'y' => round($num($me['y'] ?? 0, -50, WH + 50), 3),
        'vx' => round($num($me['vx'] ?? 0, -40, 40), 2), 'f' => ((int)($me['f'] ?? 1)) < 0 ? -1 : 1,
        'd' => (int)$num($me['d'] ?? 0, 0, 2), 'hp' => round($num($me['hp'] ?? 20, 0, 20), 1),
        'sw' => round($num($me['sw'] ?? 0, 0, 1), 2), 'h' => (int)$num($me['h'] ?? 0, 0, 255),
    ];

    // keep the lock of the chest this player has open alive
    $oc = $in['oc'] ?? null;
    if (is_array($oc) && count($oc) === 3 && is_int($oc[0] ?? null) && is_int($oc[1] ?? null) && is_int($oc[2] ?? null)
        && $oc[0] >= 0 && $oc[0] <= 2) {
        $lk = $oc[0] . '_' . $oc[1] . '_' . $oc[2];
        if (is_array($r['locks'] ?? null) && (($r['locks'][$lk]['n'] ?? '') === $name)) {
            $writes["locks/$room/$lk"] = ['n' => $name, 't' => $now];
        }
    }

    $evs = is_array($in['ev'] ?? null) ? array_slice($in['ev'], 0, MAX_EVENTS_PER_SYNC) : [];
    $i = 1; $chats = 0; $puts = 0;
    foreach ($evs as $e) {
        if (!is_array($e)) continue;
        $t = $e['t'] ?? '';
        if ($t === 'b') {
            foreach (['d', 'x', 'y', 'b'] as $k) {
                if (!isset($e[$k]) || !is_int($e[$k])) continue 2;
            }
            if ($e['d'] < 0 || $e['d'] > 2 || $e['x'] < 0 || $e['x'] >= WW || $e['y'] < 0 || $e['y'] >= WH
                || $e['b'] < 0 || $e['b'] > 255) continue;
            $writes["events/$room/" . new_event_key($now, $i++)] =
                ['t' => 'b', 'n' => $name, 'd' => $e['d'], 'x' => $e['x'], 'y' => $e['y'], 'b' => $e['b']];
            $writes["blocks/$room/{$e['d']}/{$e['x']}_{$e['y']}"] = $e['b'];
        } elseif ($t === 'p' && $puts < 10) {          // a chest / shulker box was placed: publish its starting contents
            foreach (['d', 'x', 'y'] as $k) {
                if (!isset($e[$k]) || !is_int($e[$k])) continue 2;
            }
            if ($e['d'] < 0 || $e['d'] > 2 || $e['x'] < 0 || $e['x'] >= WW || $e['y'] < 0 || $e['y'] >= WH) continue;
            if (!is_string($e['c'] ?? null) || strlen($e['c']) > MAX_BLOB || !is_array(json_decode($e['c'], true))) continue;
            $puts++;
            $writes["chests/$room/{$e['d']}_{$e['x']}_{$e['y']}"] = ['c' => $e['c'], 'saved' => $now];
        } elseif ($t === 'c' && $chats < 3) {
            $m = (string)($e['m'] ?? '');
            $m = trim(preg_replace('/[\x00-\x1f\x7f]/u', '', $m) ?? '');
            if ($m === '') continue;
            $chats++;
            $writes["events/$room/" . new_event_key($now, $i++)] = ['t' => 'c', 'n' => $name, 'm' => mb_substr($m, 0, 200)];
        }
    }

    // ---- pruning (keeps the database small); remember the newest pruned key so late clients know to resync
    $prune_to = (string)($meta['pruned'] ?? '');
    if (random_int(1, 25) === 1) {
        $cut = sprintf('%013d', $now - $cfg['event_retention'] * 1000);
        $old = $fb->get("events/$room", ['orderBy' => '"$key"', 'endAt' => json_encode($cut . '~'), 'limitToFirst' => 300]);
        if (is_array($old) && $old) {
            foreach ($old as $k => $_) {
                $writes["events/$room/$k"] = null;
                $prune_to = max($prune_to, (string)$k);
            }
            $writes["rooms/$room/pruned"] = $prune_to;
        }
    }
    $fb->update('', $writes);

    // ---- what the client gets back
    $events = [];
    $newCursor = $cursor;
    foreach ((array)$r['events'] as $k => $e) {
        if (!is_array($e) || (string)$k === $cursor) continue;
        $e['k'] = (string)$k;
        $events[] = $e;
        $newCursor = (string)$k;
    }
    $resync = $cursor !== '' && $prune_to !== '' && strcmp($cursor, $prune_to) < 0;

    $others = [];
    foreach ($players as $pn => $p) {
        if ($pn !== $name && is_array($p) && ($p['seen'] ?? 0) > $now - ONLINE_SECS * 1000) {
            $others[$pn] = public_player($p);
        }
    }
    echo json_encode([
        'ok' => true, 'players' => (object)$others, 'events' => $events, 'cursor' => $newCursor,
        'more' => count($events) >= MAX_EVENTS_PER_SYNC, 'resync' => $resync,
        'time' => $now - (int)$meta['created'],
    ]);
}

// ------------------------------------------------------------------ shared chests
function chest_key(array $in): string
{
    foreach (['d', 'x', 'y'] as $k) {
        if (!isset($in[$k]) || !is_int($in[$k])) fail('Bad chest position');
    }
    if ($in['d'] < 0 || $in['d'] > 2 || $in['x'] < 0 || $in['x'] >= WW || $in['y'] < 0 || $in['y'] >= WH) fail('Bad chest position');
    return $in['d'] . '_' . $in['x'] . '_' . $in['y'];
}

function chest_blob($c): string
{
    if (!is_string($c) || strlen($c) > MAX_BLOB || !is_array(json_decode($c, true))) fail('Bad chest data');
    return $c;
}

/** Fails with 409 when somebody else has this chest open right now. */
function lock_check(?array $lock, string $name): void
{
    if ($lock && ($lock['n'] ?? '') !== $name && ($lock['t'] ?? 0) > now_ms() - LOCK_SECS * 1000) {
        fail('That chest is in use by ' . $lock['n'] . '.', 409);
    }
}

function do_chest_open(Firebase $fb, string $room, string $name, array $in): void
{
    $key = chest_key($in);
    $r = $fb->getMulti([
        'players' => ["players/$room/$name", []],
        'lock'    => ["locks/$room/$key", []],
        'chest'   => ["chests/$room/$key", []],
    ]);
    check_token($r['players'], (string)($in['token'] ?? ''));
    lock_check($r['lock'], $name);
    $fb->update('', ["locks/$room/$key" => ['n' => $name, 't' => now_ms()]]);
    echo json_encode(['ok' => true, 'c' => is_array($r['chest']) ? ($r['chest']['c'] ?? null) : null]);
}

function do_chest_close(Firebase $fb, string $room, string $name, array $in): void
{
    $key = chest_key($in);
    $c = chest_blob($in['c'] ?? null);
    $r = $fb->getMulti(['players' => ["players/$room/$name", []], 'lock' => ["locks/$room/$key", []]]);
    check_token($r['players'], (string)($in['token'] ?? ''));
    if (!is_array($r['lock']) || ($r['lock']['n'] ?? '') !== $name) {
        fail('You no longer hold the lock on that chest, so your changes were not saved.', 409);
    }
    $fb->update('', ["chests/$room/$key" => ['c' => $c, 'saved' => now_ms()], "locks/$room/$key" => null]);
    echo json_encode(['ok' => true]);
}

/** Breaking a chest: hand over its contents once and forget it. */
function do_chest_take(Firebase $fb, string $room, string $name, array $in): void
{
    $key = chest_key($in);
    $r = $fb->getMulti([
        'players' => ["players/$room/$name", []],
        'lock'    => ["locks/$room/$key", []],
        'chest'   => ["chests/$room/$key", []],
    ]);
    check_token($r['players'], (string)($in['token'] ?? ''));
    lock_check($r['lock'], $name);
    $fb->update('', ["chests/$room/$key" => null, "locks/$room/$key" => null]);
    echo json_encode(['ok' => true, 'c' => is_array($r['chest']) ? ($r['chest']['c'] ?? null) : null]);
}

// ------------------------------------------------------------------ kick (admins only)
function do_kick(Firebase $fb, array $cfg, string $room, string $name, array $in): void
{
    $target = (string)($in['target'] ?? '');
    if (!preg_match('/^[A-Za-z0-9_]{2,16}$/', $target)) fail('Bad player name');
    $players = $fb->get("players/$room");
    check_token($players[$name] ?? null, (string)($in['token'] ?? ''));
    if (!in_array($name, $cfg['admins'], true)) fail('Only server admins can kick.', 403);
    $online = [];                                   // lowercase name => real name, only players seen recently
    foreach ((array)$players as $pn => $p) {
        if (is_array($p) && ($p['seen'] ?? 0) >= now_ms() - KICK_SECS * 1000) $online[strtolower((string)$pn)] = (string)$pn;
    }
    $match = $online[strtolower(trim($target))] ?? null;
    if ($match === null) {
        fail("Could not find '" . $target . "' (" . bin2hex($target) . ") in room '$room'. Online here: " . implode(', ', $online), 404);
    }
    if ($match === $name) fail('You cannot kick yourself.');
    $reason = mb_substr(trim(preg_replace('/[\x00-\x1f\x7f]/u', '', (string)($in['reason'] ?? '')) ?? ''), 0, 100);
    if ($reason === '') $reason = 'no reason given';
    $fb->update('', [
        "players/$room/$match/kick" => $reason,
        "players/$room/$match/seen" => 0,
        "events/$room/" . new_event_key(now_ms(), 0) => ['t' => 'k', 'n' => $match, 'by' => $name, 'm' => $reason],
    ]);
    echo json_encode(['ok' => true, 'kicked' => $match]);
}

// ------------------------------------------------------------------ snapshot (client fell too far behind)
function do_snapshot(Firebase $fb, string $room, string $name, array $in): void
{
    check_token($fb->get("players/$room/$name"), (string)($in['token'] ?? ''));
    $last = $fb->get("events/$room", ['orderBy' => '"$key"', 'limitToLast' => 1]);
    $cursor = is_array($last) && $last ? (string)array_key_last($last) : '';
    $all = $fb->get("blocks/$room");
    $blocks = [];
    foreach ((array)$all as $d => $cells) {
        if (is_array($cells)) $blocks[(string)$d] = (object)$cells;
    }
    echo json_encode(['ok' => true, 'cursor' => $cursor, 'blocks' => (object)$blocks]);
}

// ------------------------------------------------------------------ save / leave
function do_save(Firebase $fb, string $room, string $name, array $in): void
{
    $blob = $in['data'] ?? null;
    if (!is_string($blob) || strlen($blob) > MAX_BLOB || json_decode($blob) === null) fail('Bad save data');
    check_token($fb->get("players/$room/$name"), (string)($in['token'] ?? ''));
    $fb->put("pdata/$room/$name", ['blob' => $blob, 'saved' => now_ms()]);
    echo json_encode(['ok' => true]);
}

function do_leave(Firebase $fb, string $room, string $name, array $in): void
{
    $p = $fb->get("players/$room/$name");
    check_token($p, (string)($in['token'] ?? ''));
    $fb->update('', [
        "players/$room/$name/seen" => 0,
        "events/$room/" . new_event_key(now_ms(), 0) => ['t' => 'l', 'n' => $name],
    ]);
    echo json_encode(['ok' => true]);
}
