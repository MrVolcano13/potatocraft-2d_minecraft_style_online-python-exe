<?php
/*
 * PotatoCraft server configuration.
 * Everything can be set with environment variables (best for Cloud Run / Docker),
 * or by creating config.local.php next to this file that returns an array with the same keys.
 */
$cfg = [
    // Realtime Database URL, e.g. https://my-project-default-rtdb.europe-west1.firebasedatabase.app
    'db_url'          => getenv('FIREBASE_DB_URL') ?: '',

    // How the server authenticates to Firebase (first one that is set wins):
    // 1) service account JSON  - path to the key file, or the JSON itself in FIREBASE_SERVICE_ACCOUNT_JSON
    'sa_file'         => getenv('FIREBASE_SERVICE_ACCOUNT') ?: '',
    'sa_json'         => getenv('FIREBASE_SERVICE_ACCOUNT_JSON') ?: '',
    // 2) legacy database secret (Project settings > Service accounts > Database secrets)
    'db_secret'       => getenv('FIREBASE_DB_SECRET') ?: '',
    // 3) nothing set: use the Google metadata server (works on Cloud Run / App Engine / GCE)

    // Players may use /give, /setblock, /fill, creative mode, /tick
    'allow_cheats'    => getenv('POTATO_ALLOW_CHEATS') === '1',
    // Optional code that is required to CREATE a new room (stops strangers filling your database)
    'create_code'     => getenv('POTATO_CREATE_CODE') ?: '',
    // Player names allowed to use /kick, comma separated (env) or an array (config.local.php).
    // Join the room yourself first so nobody else can register your admin name.
    'admins'          => array_values(array_filter(array_map('trim', explode(',', getenv('POTATO_ADMINS') ?: '')))),
    // Limits
    'max_players'     => (int)(getenv('POTATO_MAX_PLAYERS') ?: 16),
    'event_retention' => (int)(getenv('POTATO_EVENT_RETENTION') ?: 300),   // seconds block/chat events are kept
];
$local = __DIR__ . '/config.local.php';
if (is_file($local)) {
    $cfg = array_replace($cfg, require $local);
}
return $cfg;
