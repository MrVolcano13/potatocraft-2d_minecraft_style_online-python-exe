# PotatoCraft multiplayer

```
 potatocraft_mp.py (pygame, your game)  --HTTPS/JSON-->  api.php (PHP)  --REST-->  Firebase Realtime Database
        every player                      poll ~3x/sec    the only thing that           the shared world state
                                                          can touch the database
```
Players never talk to Firebase directly: the database rules deny everything and only the PHP server
(with admin credentials) reads and writes. The PHP server validates names, passwords, block ids and coordinates.

## 1. Firebase (5 minutes)
1. Firebase console > create a project > **Build > Realtime Database > Create database** (any region, locked mode).
2. Copy the database URL (`https://<project>-default-rtdb.<region>.firebasedatabase.app`).
3. Paste `server/database.rules.json` into the Rules tab (everything denied; the server bypasses rules).
4. Credentials for the PHP server - pick one:
   * **Service account (recommended):** Project settings > Service accounts > *Generate new private key*.
     Save it as `server/service-account.json` (or set `FIREBASE_SERVICE_ACCOUNT_JSON`).
   * **Database secret (quickest for a first test):** Project settings > Service accounts > Database secrets.
     Set `FIREBASE_DB_SECRET`.
   * **Cloud Run default identity:** give the Cloud Run service account the role *Firebase Realtime Database Admin*
     and set nothing else.

## 2. Host the PHP (Firebase Hosting itself cannot run PHP)
**A. Google Cloud Run (same Google project as Firebase)**
```
cd server
gcloud run deploy potatocraft --source . --region europe-west1 --allow-unauthenticated \
  --set-env-vars FIREBASE_DB_URL=https://YOUR-DB.firebasedatabase.app,FIREBASE_DB_SECRET=...
```
The URL it prints + `/api.php` is your server URL.

**B. Any ordinary PHP host (PHP 8.1+, `curl` and `openssl` extensions)**
Upload the `server/` folder, copy `config.local.php.example` to `config.local.php` and edit it.
Make sure `config.php`, `firebase.php`, `config.local.php`, `*.json` are not downloadable (`.htaccess` does this on Apache).
Use HTTPS - passwords travel in the requests.

**Local test:** `FIREBASE_DB_URL=... FIREBASE_DB_SECRET=... php -S 127.0.0.1:8081 server/api.php`

## 3. Play
Put `potatocraft_mp.py` in the same folder as your unchanged `potatocraft.py`.
```
pip install pygame
python potatocraft_mp.py --server https://YOUR-HOST/api.php --room friends --name Tom
```
Missing options are asked (the password is always asked; a new name + password creates your account in that room).
Server/room/name are remembered in `potatocraft_mp_config.json`.
Everyone who uses the same room name shares one world. The first player creates it.

In game: **T** chat (plain text) or commands with `/`: `/players`, `/tp name`, `/kick name [reason]` (admins only), `/help`.
Admins are the player names listed in `admins` in `config.local.php` (or `POTATO_ADMINS=Tom,Anna`). Join once yourself first so nobody else registers your admin name.
**F6** (paused) saves your progress to the server; it also saves every 2 minutes and on quit (X while paused, or closing the window).

## What is synced
| Shared | Local to each player (not synced) |
|---|---|
| terrain seed, every block placed/broken in all 3 dimensions, TNT craters | mobs, the dragon, dropped items, arrows |
| other players (position, facing, held item, health, name) | chest / furnace / ender chest contents |
| contents of placed chests and shulker boxes (one player at a time) | furnace and ender chest contents |
| chat, join/leave messages, time of day | redstone machines (each client simulates them from the shared blocks) |
| your inventory, armor, XP, position (saved per name) | damage between players (no PvP yet) |

Cheats (creative mode, /give, /setblock, /fill, /tick) are disabled unless the server sets `POTATO_ALLOW_CHEATS=1`.
This is enforced by the client, so treat it as a friendly-server setting, not anti-cheat.

## Shared chests and shulker boxes
* Right-click opens the chest **fresh from the server**; closing it saves it. While you have it open nobody else can open
  or break it ("That chest is in use by Tom"), so items can't be duplicated by two people editing at once.
* A shulker box you carry keeps its contents; placing it publishes them, mining it hands them back.
* Chests and shulker boxes are blast-proof in multiplayer.
* If the server can't be reached when you close a chest, the game keeps retrying in the background.
* Unopened loot chests start with their normal seed contents for everybody; whoever opens one first takes from it.
* Database nodes: `chests/{room}` (contents) and `locks/{room}` (who has what open). Delete both when you reset a room.

## Notes and limits
* Cost: ~3 requests/second/player, each makes 2-3 Firebase calls. Fine for a handful of friends on the free tier;
  block/chat events are pruned after 5 minutes (`POTATO_EVENT_RETENTION`), the block map is kept forever.
* A client that falls more than the retention time behind automatically re-downloads the block map.
* The world has no owner/protection: anyone in the room can break anything.
* Next steps if you want them: shared furnaces, PvP, shared mobs
  (one client as host), protection regions.
